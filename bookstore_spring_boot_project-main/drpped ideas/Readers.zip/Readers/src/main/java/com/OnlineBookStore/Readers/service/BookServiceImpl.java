package com.OnlineBookStore.Readers.service;


import com.OnlineBookStore.Readers.book.book;
import com.OnlineBookStore.Readers.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookRepository bookRepository;

    @Override
    public book saveBook(book book) {
        return bookRepository.save(book);
    }

    @Override
    public List<book> findAllBooks() {
        return bookRepository.findAll();
    }

    @Override
    public book findBookById(String bookId) {
        return bookRepository.findById(bookId).orElse(null);
    }

    @Override
    public book updateBook(String bookId, book updatedBook) {
        // Check if book exists before updating
        book existingBook = bookRepository.findById(bookId).orElse(null);
        if (existingBook == null) {
            return null; // Book not found
        }

        // Update properties of existing book with provided data
        existingBook.setTitle(updatedBook.getTitle());
        existingBook.setAuthor(updatedBook.getAuthor());
        existingBook.setGenre(updatedBook.getGenre()); // Update other properties as needed
        existingBook.setSynopsis(updatedBook.getSynopsis());

        // Save the updated book
        return bookRepository.save(existingBook);
    }

    @Override
    public void deleteBookById(String bookId) {
        bookRepository.deleteById(bookId);
    }
}
