package com.OnlineBookStore.Readers.repository;

import com.OnlineBookStore.Readers.book.book;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookRepository extends JpaRepository<book, String> {

}

