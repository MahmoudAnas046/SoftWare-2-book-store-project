package com.OnlineBookStore.Readers.controller;


import com.OnlineBookStore.Readers.book.book;
import com.OnlineBookStore.Readers.service.BookServiceImpl;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/library")
public class BookController {

    private final BookServiceImpl bookServiceImpl;

    public BookController(BookServiceImpl bookServiceImpl) {
        this.bookServiceImpl = bookServiceImpl;
    }

    @PostMapping
    public ResponseEntity<book> createBook(@RequestBody book book) {
        // Basic validation for title
        if (book.getTitle() == null || book.getTitle().isEmpty()) {
            return ResponseEntity.badRequest().build();
        }


        com.OnlineBookStore.Readers.book.book savedBook = bookServiceImpl.saveBook(book);
        return ResponseEntity.ok(savedBook);
    }

    @GetMapping("/books")
    public ResponseEntity<List<book>> getAllBooks() {
        List<book> allBooks = bookServiceImpl.findAllBooks();
        return ResponseEntity.ok(allBooks);
    }

    @GetMapping("/{bookId}")
    public ResponseEntity<?> getBookById(@PathVariable String bookId) {
        book book = bookServiceImpl.findBookById(bookId);
        if (book == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(book);
    }

    @PutMapping("/{bookId}")
    public ResponseEntity<?> updateBook(@PathVariable String bookId, @RequestBody book updatedBook) {
        // Basic validation for title
        if (updatedBook.getTitle() == null || updatedBook.getTitle().isEmpty()) {
            return ResponseEntity.badRequest().body(new ErrorMessage("Book title cannot be empty"));
        }

        book savedBook = bookServiceImpl.updateBook(bookId, updatedBook);
        if (savedBook == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(savedBook);
    }

    @DeleteMapping("/{bookId}")
    public ResponseEntity<?> deleteBook(@PathVariable String bookId) {
        bookServiceImpl.deleteBookById(bookId);
        return ResponseEntity.noContent().build();
    }
}

// Class for simple error message object
class ErrorMessage {
    private final String message;

    public ErrorMessage(String message) {
        this.message = message;
    }

    public String getMessage() {
        return message;
    }
}
