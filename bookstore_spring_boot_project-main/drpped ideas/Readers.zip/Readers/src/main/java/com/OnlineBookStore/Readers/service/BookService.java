package com.OnlineBookStore.Readers.service;

import com.OnlineBookStore.Readers.book.book;

import java.util.List;

public interface BookService {

    book saveBook(book book);

    List<book> findAllBooks();

    book findBookById(String bookId);

    book updateBook(String bookId, book updatedBook);

    void deleteBookById(String bookId);
}

