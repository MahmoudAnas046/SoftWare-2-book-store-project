INSERT INTO `demo`.`book` (`id`, `title`, `author`, `genre`, `synopsis`) VALUES ('book001', 'Publication_date:', 'J.R.R. Tolkien', 'Fantasy', 'cool story')
